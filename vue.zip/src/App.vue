<template>
  <h1>Minimal Vue Webpack</h1>
  <div>
    {{ text }}
    <p>ssss</p>
  </div>
</template>

<script setup>
import { ref } from "vue";

const text = ref("Hello World!!");
</script>

<style lang="scss" scoped>
h1 {
  font-size: 20px;
}

div {
  font-size: 14px;
  p {
    color: blue;
  }
}
</style>
