import { createApp } from "vue";
import App from "./src/App";

createApp(App).mount("#app");
